import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * counts word occurrences in a given input file and outputs an HTML document
 * with a table of the words and counts listed in alphabetical order.
 *
 * @author Zhiren Xu
 */
public final class wordCounter {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private wordCounter() {
        // no code needed here
    }

    /**
     * Comparator for queue which used in wordCount method. This comparator is
     * used to put all words in alphabet order.
     */
    private static class StringLT implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            return o1.compareTo(o2);
        }
    }

    /**
     * Separate words from input file and add them into a map.
     *
     * @param input
     *            The input file
     * @return a map that contain all words and their counts
     */
    public static Map<String, Integer> wordCount(String input) {
        SimpleReader fileIn = new SimpleReader1L(input);
        Queue<String> words = new Queue1L<>();
        Map<String, Integer> count = new Map1L<>();
        String characterBase = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz";
        while (!fileIn.atEOS()) {
            String line = fileIn.nextLine().trim();
            /*
             * Find all blank in the line and use it as separator.
             */
            while (!line.isEmpty()) {
                int blankIndex = line.indexOf(" ");
                /*
                 * Once get the word, check if there are any symbols in it. Use
                 * a loop to get rid of these symbols, then add them in queue.
                 */
                if (blankIndex != -1) {
                    String candidate = line.substring(0, blankIndex);
                    for (int i = 0; i < candidate.length(); i++) {
                        char ch = candidate.charAt(i);
                        int pos = characterBase.indexOf(Character.toString(ch));
                        if (pos == -1) {
                            candidate = candidate.substring(0, i);
                        }
                    }
                    words.enqueue(candidate);
                    line = line.substring(blankIndex + 1);
                } else {
                    words.enqueue(line);
                    line = line.substring(line.length());
                }
            }
        }
        /*
         * First sort queue words, then add key and value to map.
         */
        Comparator<String> ci = new StringLT();
        words.sort(ci);
        while (words.length() != 0) {
            String str = words.dequeue();
            if (count.size() == 0) {
                count.add(str, 1);
            } else {
                if (count.hasKey(str)) {
                    int counter = count.value(str);
                    counter++;
                    count.replaceValue(str, counter);
                } else {
                    count.add(str, 1);
                }
            }
        }
        fileIn.close();
        return count;
    }

    /**
     * Output the html file using info from map.
     *
     * @param inFile
     *            file name for html title
     * @param outFile
     *            the target html that need to write info in.
     * @param count
     *            the map which contain words and their appear times.
     */
    public static void outputFileWriter(String inFile, String outFile,
            Map<String, Integer> count) {
        SimpleWriter fileOut = new SimpleWriter1L(outFile);
        /*
         * Draw map pairs from count into a queue for word, then sort it. Later
         * use the queue to find value from count.
         */
        Map<String, Integer> temp = count.newInstance();
        Queue<String> name = new Queue1L<>();
        while (count.size() != 0) {
            Map.Pair<String, Integer> currentWord = count.removeAny();
            name.enqueue(currentWord.key());
            temp.add(currentWord.key(), currentWord.value());
        }
        count.transferFrom(temp);
        Comparator<String> ci = new StringLT();
        name.sort(ci);
        /*
         * Build html.
         */
        fileOut.println("<html>");
        fileOut.println("<head>");
        fileOut.println("<title>Words Counted in " + inFile + "</title>");
        fileOut.println("</head>");
        fileOut.println("<body>");
        fileOut.println("<h2>Words Counted in " + inFile + "</h2>");
        fileOut.println("<hr />");
        fileOut.println("<table border=\"1\">");
        fileOut.println("<tr>");
        fileOut.println("<th>Words</th>");
        fileOut.println("<th>Counts</th>");
        fileOut.println("</tr>");
        while (name.length() != 0) {
            String str = name.dequeue();
            fileOut.println("<tr>");
            fileOut.println("<td>" + str + "</td>");
            fileOut.println("<td>" + count.value(str) + "</td>");
            fileOut.println("</tr>");
        }
        fileOut.println("</table>");
        fileOut.println("</body>");
        fileOut.println("</html>");
        fileOut.close();
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        out.print("Please enter the name of an input file: ");
        String inputFile = in.nextLine();
        out.print("Please enter the name of an output file: ");
        String outputFile = in.nextLine();
        in.close();
        out.close();
        Map<String, Integer> result = wordCount(inputFile);
        outputFileWriter(inputFile, outputFile, result);
    }
}
