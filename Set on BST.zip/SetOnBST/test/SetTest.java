import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Zhizhou He Zhiren Xu
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, contains, and size
    /**
     * Test case for empty constructor call.
     */
    @Test
    public void testEmptyConstructor() {
        Set<String> set = this.createFromArgsTest();
        Set<String> setExpected = this.createFromArgsRef();
        assertEquals(setExpected, set);
    }

    /**
     * Test case for empty constructor call.
     */
    @Test
    public void testNonEmptyConstructor() {
        Set<String> set = this.createFromArgsTest("C");
        Set<String> setExpected = this.createFromArgsRef("C");
        assertEquals(setExpected, set);
    }

    /**
     * Test case for add method, add single empty string.
     */
    @Test
    public void testAddEmptyString() {
        Set<String> set = this.createFromArgsTest();
        Set<String> setExpected = this.createFromArgsRef("");
        set.add("");
        assertEquals(setExpected, set);
    }

    /**
     * Test case for add method, add a non-empty string on empty.
     */
    @Test
    public final void testAddOnEmpty() {
        Set<String> set = this.createFromArgsTest();
        Set<String> setExpected = this.createFromArgsRef("C");
        set.add("C");
        assertEquals(setExpected, set);
    }

    /**
     * Test case for add method, add a non-empty string on non-empty.
     */
    @Test
    public final void testAddOnNonEmpty() {
        Set<String> set = this.createFromArgsTest("C", "S");
        Set<String> setExpected = this.createFromArgsRef("C", "S", "E");
        set.add("E");
        assertEquals(setExpected, set);
    }

    /**
     * Test case for remove method, remove a non-empty string and it leaves
     * empty.
     */
    @Test
    public final void testRemoveEmpty() {
        Set<String> set = this.createFromArgsTest("C");
        Set<String> setExpected = this.createFromArgsRef();
        String x = set.remove("C");
        assertEquals(setExpected, set);
        assertEquals(x, "C");
    }

    /**
     * Test case for remove method, remove a non-empty string and it leaves
     * non-empty.
     */
    @Test
    public final void testRemoveNonEmpty() {
        Set<String> set = this.createFromArgsTest("C", "S", "E");
        Set<String> setExpected = this.createFromArgsRef("C", "S");
        String x = set.remove("E");
        assertEquals(setExpected, set);
        assertEquals(x, "E");
    }

    /**
     * Test case for removeAny method, remove a empty string and it leaves
     * non-empty.
     */
    @Test
    public final void testRemoveAnyNonEmpty() {
        Set<String> set = this.createFromArgsTest("C", "S", "E");
        Set<String> setExpected = this.createFromArgsRef("C", "S", "E");
        String x = set.removeAny();
        assertTrue(!set.contains(x));
        assertTrue(setExpected.contains(x));
        setExpected.remove(x);
        assertEquals(setExpected, set);
    }

    /**
     * Test case for removeAny method, remove a non-empty string and it leaves
     * empty.
     */
    @Test
    public final void testRemoveAnyToEmpty() {
        Set<String> set = this.createFromArgsTest("C");
        Set<String> setExpected = this.createFromArgsRef("C");
        String x = set.removeAny();
        assertTrue(!set.contains(x));
        assertTrue(setExpected.contains(x));
        setExpected.remove(x);
        assertEquals(setExpected, set);
        assertEquals(x, "C");
    }

    /**
     * Test case for contains method --empty.
     */
    @Test
    public final void testContainsEmpty() {
        Set<String> set = this.createFromArgsTest();
        Set<String> setExpected = this.createFromArgsRef();
        assertTrue(!set.contains("C"));
        assertEquals(setExpected, set);
    }

    /**
     * Test case for contains method --non-empty.
     */
    @Test
    public final void testContainsNonEmpty() {
        Set<String> set = this.createFromArgsTest("C", "S", "E");
        Set<String> setExpected = this.createFromArgsRef("C", "S", "E");
        assertTrue(set.contains("C"));
        assertEquals(setExpected, set);
    }

    /**
     * Test case for contains method --non-empty and it doesn't contain.
     */
    @Test
    public final void testNotContainsNonEmpty() {
        Set<String> set = this.createFromArgsTest("C", "S", "E");
        Set<String> setExpected = this.createFromArgsRef("C", "S", "E");
        assertTrue(!set.contains("2231"));
        assertEquals(setExpected, set);
    }

    /**
     * Test case for size method --empty.
     */
    @Test
    public final void testSizeEmpty() {
        Set<String> set = this.createFromArgsTest();
        Set<String> setExpected = this.createFromArgsRef();
        assertEquals(set.size(), 0);
        assertEquals(setExpected, set);
    }

    /**
     * Test case for size method --nonempty.
     */
    @Test
    public final void testSizeNonEmpty() {
        Set<String> set = this.createFromArgsTest("C", "S", "E");
        Set<String> setExpected = this.createFromArgsRef("C", "S", "E");
        assertEquals(set.size(), 3);
        assertEquals(setExpected, set);
    }

}
