
import components.map.Map;
import components.program.Program;
import components.program.Program1;
import components.queue.Queue;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.statement.Statement;
import components.utilities.Reporter;
import components.utilities.Tokenizer;

/**
 * Layered implementation of secondary method {@code parse} for {@code Program}.
 *
 * @author Zhiren Xu Zhizhou He Cenlin Bao
 *
 */
public final class Program1Parse1 extends Program1 {

    /*
     * Private members --------------------------------------------------------
     */

    /**
     * Parses a single BL instruction from {@code tokens} returning the
     * instruction name as the value of the function and the body of the
     * instruction in {@code body}.
     *
     * @param tokens
     *            the input tokens
     * @param body
     *            the instruction body
     * @return the instruction name
     * @replaces body
     * @updates tokens
     * @requires <pre>
     * [<"INSTRUCTION"> is a prefix of tokens]  and
     *  [<Tokenizer.END_OF_INPUT> is a suffix of tokens]
     * </pre>
     * @ensures <pre>
     * if [an instruction string is a proper prefix of #tokens]  and
     *    [the beginning name of this instruction equals its ending name]  and
     *    [the name of this instruction does not equal the name of a primitive
     *     instruction in the BL language] then
     *  parseInstruction = [name of instruction at start of #tokens]  and
     *  body = [Statement corresponding to statement string of body of
     *          instruction at start of #tokens]  and
     *  #tokens = [instruction string at start of #tokens] * tokens
     * else
     *  [report an appropriate error message to the console and terminate client]
     * </pre>
     */
    private static String parseInstruction(Queue<String> tokens,
            Statement body) {
        assert tokens != null : "Violation of: tokens is not null";
        assert body != null : "Violation of: body is not null";
        assert tokens.length() > 0 && tokens.front().equals("INSTRUCTION") : ""
                + "Violation of: <\"INSTRUCTION\"> is proper prefix of tokens";
// is test case wrong spelling "INSTRUCTION" needed?

        tokens.dequeue();

        String beginningName = tokens.dequeue();
        boolean isIdentifier = Tokenizer.isIdentifier(beginningName);
        Reporter.assertElseFatalError(isIdentifier,
                "Error: invalid identifier");

        Reporter.assertElseFatalError(
                !beginningName.equals("move")
                        && !beginningName.equals("turnleft")
                        && !beginningName.equals("turnright")
                        && !beginningName.equals("skip")
                        && !beginningName.equals("infect"),
                "Error: The name of this instruction cannot be any of the primitiveinstruction in the BL language");

        boolean checkSyntax = tokens.front().equals("IS");
        Reporter.assertElseFatalError(checkSyntax, "Syntax Error: missing IS");
        tokens.dequeue();

        body.parseBlock(tokens);

        checkSyntax = tokens.front().equals("END");
        Reporter.assertElseFatalError(checkSyntax, "Syntax Error: missing END");
        tokens.dequeue();

        String endingName = tokens.dequeue();
        boolean isEqual = beginningName.equals(endingName);
        Reporter.assertElseFatalError(isEqual,
                "Violation of: the beginning name of this instruction equals its ending name");

        boolean isMatch = !beginningName.equalsIgnoreCase("move")
                && !beginningName.equalsIgnoreCase("turnleft")
                && !beginningName.equalsIgnoreCase("turnright")
                && !beginningName.equalsIgnoreCase("infect")
                && !beginningName.equalsIgnoreCase("skip");
        Reporter.assertElseFatalError(isMatch,
                "Error: The name of this instruction cannot be any of the primitiveinstruction in the BL language");

        return beginningName;
    }

    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * No-argument constructor.
     */
    public Program1Parse1() {
        super();
    }

    /*
     * Public methods ---------------------------------------------------------
     */

    @Override
    public void parse(SimpleReader in) {
        assert in != null : "Violation of: in is not null";
        assert in.isOpen() : "Violation of: in.is_open";
        Queue<String> tokens = Tokenizer.tokens(in);
        this.parse(tokens);
    }

    @Override
    public void parse(Queue<String> tokens) {
        assert tokens != null : "Violation of: tokens is not null";
        assert tokens.length() > 0 : ""
                + "Violation of: Tokenizer.END_OF_INPUT is a suffix of tokens";

        boolean checkSyntax = tokens.front().equals("PROGRAM");
        Reporter.assertElseFatalError(checkSyntax,
                "Syntax Error: missing PROGRAM");
        tokens.dequeue();

        boolean isIdentifier = Tokenizer.isIdentifier(tokens.front());
        Reporter.assertElseFatalError(isIdentifier,
                "Error: invalid identifier");
        String programIdentifier = tokens.dequeue();

        boolean isMatch = !programIdentifier.equalsIgnoreCase("move")
                && !programIdentifier.equalsIgnoreCase("turnleft")
                && !programIdentifier.equalsIgnoreCase("turnright")
                && !programIdentifier.equalsIgnoreCase("infect")
                && !programIdentifier.equalsIgnoreCase("skip");
        Reporter.assertElseFatalError(isMatch,
                "Error: The name of the program cannot be any of the primitiveinstruction in the BL language");

        checkSyntax = tokens.front().equals("IS");
        Reporter.assertElseFatalError(checkSyntax, "Syntax Error: missing IS");
        tokens.dequeue();

        Map<String, Statement> newContext = this.newContext();
        while (!tokens.front().equals("BEGIN")) {
            Statement b = this.newBody();
            String contextName = parseInstruction(tokens, b);
            boolean isUnique = !newContext.hasKey(contextName);
            Reporter.assertElseFatalError(isUnique,
                    "Violation of: The name of each new user-defined instruction must be unique");
            newContext.add(contextName, b);
        }

        this.swapContext(newContext);

        tokens.dequeue();
        Statement b = this.newBody();
        b.parseBlock(tokens);
        this.swapBody(b);

        checkSyntax = tokens.front().equals("END");
        Reporter.assertElseFatalError(checkSyntax, "Syntax Error: missing END");
        tokens.dequeue();

        String endingName = tokens.dequeue();
        boolean pNameIsEqual = programIdentifier.equals(endingName);
        Reporter.assertElseFatalError(pNameIsEqual,
                "Violation of: the beginning name of this program equals its ending name");
        this.setName(endingName);

        boolean noTrash = tokens.front().equals(Tokenizer.END_OF_INPUT);
        Reporter.assertElseFatalError(noTrash,
                "extra stuff cannot appear after the end of the program");
    }

    /*
     * Main test method -------------------------------------------------------
     */

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Get input file name
         */
        out.print("Enter valid BL program file name: ");
        String fileName = in.nextLine();
        /*
         * Parse input file
         */
        out.println("*** Parsing input file ***");
        Program p = new Program1Parse1();
        SimpleReader file = new SimpleReader1L(fileName);
        Queue<String> tokens = Tokenizer.tokens(file);
        file.close();
        p.parse(tokens);
        /*
         * Pretty print the program
         */
        out.println("*** Pretty print of parsed program ***");
        p.prettyPrint(out);

        in.close();
        out.close();
    }

}
