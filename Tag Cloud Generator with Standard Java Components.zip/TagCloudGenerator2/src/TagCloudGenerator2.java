import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

/**
 * Put a short phrase describing the program here.
 *
 * @Project 9 Tag Cloud Generator
 * @author Zhizhou He
 *
 */
public final class TagCloudGenerator2 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudGenerator2() {
    }

    /**
     * String of separators.
     */
    static final String SEPARATOR_STR = " \t\n\r\\\"(){}[]<>`':;,.?!-_/~@#$%^&*|";
    /**
     * String of alphabet character.
     */
    static final String A_TO_Z = "abcdefghijklmnopqrstuvwxyz";

    /**
     * Maximum font size.
     */
    private static final int MAX = 48;
    /**
     * Minimum font size.
     */
    private static final int MIN = 11;

    /**
     * Integer number: 1.
     */
    static final int ONE = 1;

    /**
     * compare based on counting number.
     */
    private static class MapPairCompareCount
            implements Comparator<Map.Entry<String, Integer>> {

        @Override
        public int compare(Map.Entry<String, Integer> o1,
                Map.Entry<String, Integer> o2) {
            return o2.getValue().compareTo(o1.getValue());
        }
    }

    /**
     * compare based on alphabetic order, ignore case sensitive.
     **/
    private static class MapPairCompareAlpha
            implements Comparator<Map.Entry<String, Integer>> {

        @Override
        public int compare(Map.Entry<String, Integer> o1,
                Map.Entry<String, Integer> o2) {
            return o1.getKey().toLowerCase()
                    .compareTo(o2.getKey().toLowerCase());
        }
    }

    /**
     * Generate a Set which contains elements in the input String.
     *
     * @param str
     *            input String
     * @param strSet
     *            a set of characters to be replaced
     */
    private static void generateSet(String str, Set<Character> strSet) {
        assert str != null : "Violation: str is not null";
        assert strSet != null : "Violation: strSet is not null";

        strSet.clear();
        for (int i = 0; i < str.length(); i++) {
            strSet.add(str.charAt(i));
        }

    }

    /**
     * Get words and separators from String text.
     *
     * @param text
     *            A string which contains words and/or separtors.
     * @param position
     *            starting index
     * @param separator
     *            the set of characters of separator
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separator) {
        assert text != null : "Violation: text is not null";
        assert 0 <= position : "Violation: 0 <= position";
        assert position < text.length() : "Violation: position < |text|";

        int i = position;
        boolean ifContain = separator.contains(text.charAt(position));
        while (i < text.length()
                && ifContain == separator.contains(text.charAt(i))) {
            i++;
        }
        String result = text.substring(position, i);
        return result;
    }

    /**
     * Count number of appearance of words.
     *
     * @param counter
     *            a map that contain words as key and its number of appearance
     *            as value
     * @param separator
     *            a set of separator character
     * @param inputFile2
     *            provide input of words
     * @update counter
     * @require text.length > 0
     */
    private static void generateWordCount(Map<String, Integer> counter,
            Set<Character> separator, BufferedReader inputFile2) {

        assert counter != null : "Violation: text is not null.";
        assert separator != null : "Violation: separator is not null.";
        assert inputFile2 != null : "Violation: in is not null.";

        //need to revised
        counter.clear();
        try {
            String s = inputFile2.readLine();
            int pos = 0;
             while (s != null) {
                if (!s.isEmpty() && pos < s.length()) {
                    String token = nextWordOrSeparator(s, pos, separator)
                            .toLowerCase();
                    if (!separator.contains(token.charAt(0))) {
                        if (counter.containsKey(token)) {
                            Set<Map.Entry<String, Integer>> set = counter
                                    .entrySet();
                            for (Entry<String, Integer> i : set) {
                                if (i.getKey().equals(token)) {
                                    int val = i.getValue();
                                    i.setValue(val + 1);
                                }
                            }
                        } else {
                            // if it is a word, add in Map counter,
                            //if it is already in map, make its value ++
                            counter.put(token, ONE);
                        }
                    }
                    pos += token.length();
                } else {
                    s = inputFile2.readLine();
                    pos = 0;
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading from file");
        }
    }

    /**
     * Generate a tagCloud html web page.
     *
     * @param sm
     *            A sorting machine to sort words from highest
     * @param n
     *            number of words shown in the webpage
     * @param out
     *            output file writer
     * @param inputFileName
     *            an input file that provides words
     */
    private static void generateTagCloud(List<Map.Entry<String, Integer>> sm,
            int n, PrintWriter out, String inputFileName) {

        assert sm != null : "Violation of: sortByCount cannot be null.";
        assert n >= 0 : "Violation of: N is great or equal than 0.";

        out.println("<html>");
        out.println("<head>");
        String word;
        if (n == 1) {
            word = "word";
        } else {
            word = "words";
        }
        out.println("<title>Top " + n + " " + word + " in " + inputFileName
                + "</title>");
        out.println(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println("</head>");
        out.println("<body>");
        String sORp;
        if (n == 1) {
            sORp = "word";
        } else {
            sORp = "words";
        }
        out.println(
                "<h2>Top " + n + " " + sORp + " in " + inputFileName + "</h2>");
        out.println("<hr>");
        out.println("<div class=\"cdiv\">");
        out.println("<p class=\"cbox\">");

        // generate Web page header and title

        int smallest = 0;
        int biggest = 0;

        Comparator<Map.Entry<String, Integer>> order = new MapPairCompareAlpha();
        List<Map.Entry<String, Integer>> alphaSort = new ArrayList<>();

        //if the file is empty,output nothing

        //if there's only one word, there's no smallest,set the only one biggest font
        if (n > 0) {
            Map.Entry<String, Integer> first = sm.remove(0);
            biggest = first.getValue();
            alphaSort.add(first);
            smallest = 0;

            //if there's more than one words, get biggest and smallest
            if (n > 1) {
                int sizeExceptSmallest = n - 2;
                for (int i = 0; i < sizeExceptSmallest; i++) {
                    alphaSort.add(sm.remove(0));
                }
                Map.Entry<String, Integer> last = sm.remove(0);
                smallest = last.getValue();
                alphaSort.add(last);
            }
            alphaSort.sort(order);
        }

        // calculate font size

        for (int i = 0; i < n; i++) {
            int size;
            Map.Entry<String, Integer> element = alphaSort.remove(0);
            if (biggest != smallest) {
                size = (MAX - MIN) * (element.getValue() - smallest)
                        / (biggest - smallest) + MIN;
            } else {
                size = MAX;
            }

            out.println("<span style=\"cursor:default\" class=\"" + "f" + size
                    + "\"" + " title=\"count: " + element.getValue() + "\">"
                    + element.getKey() + "</span>");
        }
        out.println("</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
        out.close();
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */

    public static void main(String[] args) {

        //---------- get basic information

        Scanner in = new Scanner(System.in);
        System.out.print("Enter an input file name: ");

        String inputFileName = in.nextLine();
        BufferedReader inputFile = null;
        try {
            inputFile = new BufferedReader(new FileReader(inputFileName));
        } catch (IOException e) {
            System.err.println("Error opening input file");
        }
        if (inputFile != null) {
            System.out.print("Enter an output file name: ");
            String outputFileName = in.nextLine();
            PrintWriter outputFile = null;
            try {
                outputFile = new PrintWriter(
                        new BufferedWriter(new FileWriter(outputFileName)));
            } catch (IOException e) {
                System.err.println("Error creating file.");
            }
            if (outputFile != null) {
                System.out.print("Enter the number of words "
                        + "you want to use to generate a tag cloud: ");

                // test if input is integer
                boolean flag = true;
                int n = 0;
                while (flag) {
                    String num = in.nextLine();

                    try {
                        n = Integer.parseInt(num);
                        if (n < 0) {
                            System.err.println(
                                    "invalid input, please enter a positive integer: ");
                        } else {
                            flag = false;
                        }
//                    assert n > 0 : "Error: number can't be negative.";
                    } catch (NumberFormatException e) {
                        System.err.println(
                                "invalid input, please enter a positive integer:");
                    }

                }

                Set<Character> separatorSet = new HashSet<>();
                generateSet(SEPARATOR_STR, separatorSet);

                Map<String, Integer> text = new HashMap<>();
                generateWordCount(text, separatorSet, inputFile);

                Comparator<Map.Entry<String, Integer>> orderByCount = new MapPairCompareCount();

                List<Map.Entry<String, Integer>> mapList = new ArrayList<>();
                // put all Map Entry(Map Pair in an Iterator, to check next& remove)
                Iterator<Map.Entry<String, Integer>> it = text.entrySet()
                        .iterator();

                while (it.hasNext()) {
                    Map.Entry<String, Integer> element = it.next();
                    it.remove();
                    mapList.add(element);
                }
                Collections.sort(mapList, orderByCount);

                // if input N is greater than total unique words, let N = #unique words
                if (n > mapList.size()) {
                    n = mapList.size();
                    System.err.println("Input number > number of total words. "
                            + "Program will use all words "
                            + "to generate a tag cloud instead.");
                }
                generateTagCloud(mapList, n, outputFile, inputFileName);
            }
            try {
                inputFile.close();
            } catch (IOException e) {
                System.err.println("Error closing file.");
            }
        }
        in.close();
    }

}