
import java.util.Comparator;

import components.map.Map;
import components.map.Map.Pair;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence3;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine2;

/**
 * Put a short phrase describing the program here.
 *
 * @Project 9 Tag Cloud Generator
 * @author Zhizhou He Zhiren Xu Cenlin Bao
 *
 */
public final class TagCloudGenerator {

    // compare count number, then, alphabetic order

    private TagCloudGenerator() {
    }

    final static String separatorStr = " \t\n\r\\\"`':;,.?!(){}[]<>-_/~@#$%^&*|0123456789";
    final static int ONE = 1;
    final static int numOfFontSize = 37;
    final static int iniFont = 11;

    /**
     *
     * compare based on counting number
     */
    private static class MapPairCompareCount
            implements Comparator<Map.Pair<String, Integer>> {

        @Override
        public int compare(Pair<String, Integer> o1, Pair<String, Integer> o2) {
            return o1.value().compareTo(o2.value());
        }
    }

    /**
     * compare based on alphabetic order, ignore case sensitive
     */
    private static class MapPairCompareAlpha
            implements Comparator<Map.Pair<String, Integer>> {

        // set both to lower case to compare
        @Override
        public int compare(Pair<String, Integer> o1, Pair<String, Integer> o2) {
            return o1.key().toLowerCase().compareTo(o2.key().toLowerCase());
        }

    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code SEPARATORS}) or "separator string" (maximal length string of
     * characters in {@code SEPARATORS}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection entries(SEPARATORS) = {}
     * then
     *   entries(nextWordOrSeparator) intersection entries(SEPARATORS) = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection entries(SEPARATORS) /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of entries(SEPARATORS)  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of entries(SEPARATORS))
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position) {
        assert text != null : "Violation of: text is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";
        StringBuilder returnText = new StringBuilder();
        if (separatorStr.contains(String.valueOf(text.charAt(position)))) {
            for (int i = position; i < text.length() && separatorStr
                    .contains(String.valueOf(text.charAt(i))); i++) {
                returnText.append(text.charAt(i));
            }
        } else {
            for (int i = position; i < text.length() && !separatorStr
                    .contains(String.valueOf(text.charAt(i))); i++) {
                returnText.append(text.charAt(i));
            }
        }
        return returnText.toString().toLowerCase();
    }

    /**
     * Count number of appearance of words.
     *
     * @param counter
     *            a map that contain words as key and its number of appearance
     *            as value
     * @param in
     *            provide input of words
     * @update counter
     * @require text.length > 0
     */
    private static void generateWordCount(Map<String, Integer> counter,
            SimpleReader in) {

        while (!in.atEOS()) {
            String ReadinLine = in.nextLine();
            int pos = 0;
            while (pos < ReadinLine.length()) {
                String text = nextWordOrSeparator(ReadinLine, pos);
                if (!separatorStr.contains(String.valueOf(text.charAt(0)))) {
                    /*
                     * Add new element to Map, value start at 1. And enqueue the
                     * keys
                     */
                    if (!counter.hasKey(text)) {
                        counter.add(text, 1);

                    } else {
                        int value = counter.value(text);
                        counter.replaceValue(text, ++value);
                    }
                }
                pos += text.length();
            }
        }
    }

    /**
     * sort the map that contain words and number of appearance by alphabetic
     * order and return as a sequence.
     *
     * @param count
     *            The map that contain words and number of appearance
     * @param N
     *            The number of words client want to display
     * @return a sequence of Map.pair<String, Integer> sorted by alphabetic
     *         order.
     */
    private static Sequence<Map.Pair<String, Integer>> alphaSort(
            Map<String, Integer> count, int N) {

        Comparator<Map.Pair<String, Integer>> order = new MapPairCompareAlpha();
        SortingMachine<Map.Pair<String, Integer>> alphaSm = new SortingMachine2<>(
                order);
        Sequence<Map.Pair<String, Integer>> seq = new Sequence3<>();
        //sort word data in alphabetic order.
        while (count.size() > 0) {
            alphaSm.add(count.removeAny());
        }
        alphaSm.changeToExtractionMode();

        //seq will be a sequence with the front N words in alphabetical order
        for (int i = 0; i < N; i++) {
            Map.Pair<String, Integer> p = alphaSm.removeFirst();
            seq.add(i, p);
            count.add(p.key(), p.value());
        }
        return seq;
    }

    /**
     * Get maximum number of appearance among all words.
     *
     * @param seq
     *            A sequence of map pair that contain all word and their number
     *            of appearance
     * @return an integer contains maximum number of appearance.
     */
    private static int getUpperBound(Sequence<Map.Pair<String, Integer>> seq) {
        Comparator<Map.Pair<String, Integer>> numOrder = new MapPairCompareCount();
        SortingMachine<Map.Pair<String, Integer>> numSort = new SortingMachine2<>(
                numOrder);
        //use sorting machine to get maximum/minimum appearance.
        for (int i = 0; i < seq.length(); i++) {
            numSort.add(seq.entry(i));
        }
        numSort.changeToExtractionMode();
        while (numSort.size() > 1) {
            numSort.removeFirst();
        }
        int max = numSort.removeFirst().value();
        return max;
    }

    /**
     * calculate the gap between font size.
     *
     * @param max
     *            The maximum value of number of appearance for a word.
     *
     * @return The gap between each font size
     */
    private static int getFontDiff(int max) {
        //We can only use 37 kinds of font size, so we must divide.
        int fontDiff = max / numOfFontSize;
        return fontDiff;
    }

    /**
     * Transfer number of appearance of one word to font size it should has.
     *
     * @param data
     *            A Map.Pair contain info about number of appearance of a word.
     * @param fontDiff
     *            The gap between each font size, use to calculate font size
     * @return an Integer which represent the font size of word in this map pair
     */
    private static int getFont(Map.Pair<String, Integer> data, int fontDiff) {
        int ratio = data.value() / fontDiff;
        int fontSize = iniFont + ratio;
        return fontSize;
    }

    /**
     * Generate a tagCloud html web page.
     *
     * @param count
     *            A map contain words and their font
     * @param wordsInAlpha
     *            A sequence of map pair which sorted in alphabet order
     * @param N
     *            The number of words clients want to display on html
     * @param out
     *            output file writer
     * @param inputFileName
     *            an input file that provides words
     *
     */
    private static void generateTagCloud(Map<String, Integer> count,
            Sequence<Map.Pair<String, Integer>> wordsInAlpha, int N,
            SimpleWriter out, String inputFileName) {

        out.println("<html>");
        out.println("<head>");
        out.println(
                "<title>Top " + N + " words in " + inputFileName + "</title>");
        out.println(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Top " + N + " words in " + inputFileName + "</h2>");
        out.println("<hr>");
        out.println("<div class=\"cdiv\">");
        out.println("<p class=\"cbox\">");

        for (int i = 0; i < N; i++) {
            Map.Pair<String, Integer> data = wordsInAlpha.remove(0);
            String key = data.key();
            int appearNum = data.value();
            int font = count.value(key);
            out.println("<span style=\"cursor:default\" class=\"" + "f" + font
                    + "\"" + " title=\"count: " + appearNum + "\">" + key
                    + "</span>");
        }
        out.println("</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }

    public static void main(String[] args) {

        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter an input file name:");
        String inputFileName = in.nextLine();
        SimpleReader inputFile = new SimpleReader1L(inputFileName);

        out.print("Enter an output file name:");
        String outputFileName = in.nextLine();
        SimpleWriter outputFile = new SimpleWriter1L(outputFileName);

        out.print(
                "Enter the number of words you want to use to generate a tag cloud: ");
        int num = in.nextInteger();

        while (num < 0) {
            out.print("Invalid input, please enter a positive number:");
            num = in.nextInteger();
        }

        Map<String, Integer> wordsAndNum = new Map1L<String, Integer>();
        /*
         * Get contents from input file
         */
        generateWordCount(wordsAndNum, inputFile);
        /*
         * Sort
         */
        Sequence<Map.Pair<String, Integer>> wordsInAlpha = alphaSort(
                wordsAndNum, num);
        /*
         * Find the maximum value of word appearance
         */
        int maximum = getUpperBound(wordsInAlpha);
        /*
         * Get font for each word
         */
        int fontGap = getFontDiff(maximum);

        Map<String, Integer> temp = wordsAndNum.newInstance();
        temp.transferFrom(wordsAndNum);
        while (temp.size() > 0) {
            Map.Pair<String, Integer> data = temp.removeAny();
            String word = data.key();
            int font = getFont(data, fontGap);
            wordsAndNum.add(word, font);
        }
        /*
         * Generate Homepage
         */
        generateTagCloud(wordsAndNum, wordsInAlpha, num, outputFile,
                inputFileName);

        in.close();
        out.close();
        inputFile.close();
        outputFile.close();
    }

}