import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;

public class TagCloudGeneratorTest {

    @Test
    public void testnextWordOrSeparator1() {
        String text = "aa-bb,cc";
        Set<Character> separators = new Set1L<>();
        separators.add('-');

        String res = TagCloudGenerator.nextWordOrSeparator(text, 0);
        assertEquals("aa", res);
    }

    @Test
    public void testnextWordOrSeparator2() {
        String text = "aa,bb,cc";
        Set<Character> separators = new Set1L<>();
        separators.add(',');

        String res = TagCloudGenerator.nextWordOrSeparator(text, 2);
        assertEquals(",", res);
    }

    @Test
    public void testnextWordOrSeparator3() {
        String text = "aa,bb,cc";
        Set<Character> separators = new Set1L<>();
        separators.add(',');

        String res = TagCloudGenerator.nextWordOrSeparator(text, 0);
        assertEquals(false, res == "aa,");
    }

}
