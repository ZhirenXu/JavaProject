import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Customized JUnit test fixture for {@code NaturalNumber3}.
 */
public class NaturalNumber3Test extends NaturalNumberTest {

    @Override
    protected final NaturalNumber constructorTest() {
        NaturalNumber nn = new NaturalNumber3();
        return nn;
    }

    @Override
    protected final NaturalNumber constructorTest(int i) {
        NaturalNumber nn = new NaturalNumber3(i);
        return nn;
    }

    @Override
    protected final NaturalNumber constructorTest(String s) {
        NaturalNumber nn = new NaturalNumber3(s);
        return nn;
    }

    @Override
    protected final NaturalNumber constructorTest(NaturalNumber n) {
        NaturalNumber nn = new NaturalNumber3(n);
        return nn;
    }

    @Override
    protected final NaturalNumber constructorRef() {
        NaturalNumber nn = new NaturalNumber2();
        return nn;
    }

    @Override
    protected final NaturalNumber constructorRef(int i) {
        NaturalNumber nn = new NaturalNumber2(i);
        return nn;
    }

    @Override
    protected final NaturalNumber constructorRef(String s) {
        NaturalNumber nn = new NaturalNumber2(s);
        return nn;
    }

    @Override
    protected final NaturalNumber constructorRef(NaturalNumber n) {
        NaturalNumber nn = new NaturalNumber2(n);
        return nn;
    }

}
