import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Zhiren Xu Zhizhou He
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    /**
     * Empty input constructor test.
     */
    @Test
    public final void testNonArgumentConstructor() {
        NaturalNumber a = this.constructorTest();
        NaturalNumber aExpected = this.constructorRef();
        assertEquals(aExpected, a);
    }

    /**
     * Integer input--0 constructor test.
     */
    @Test
    public final void testInt0ArgumentConstructor() {
        int i = 0;
        NaturalNumber a = this.constructorTest(i);
        NaturalNumber aExpected = this.constructorRef(i);
        assertEquals(aExpected, a);
    }

    /**
     * Integer input--normal constructor test.
     */
    @Test
    public final void testIntNormalArgumentConstructor() {
        final int i = 5;
        NaturalNumber a = this.constructorTest(i);
        NaturalNumber aExpected = this.constructorRef(i);
        assertEquals(aExpected, a);
    }

    /**
     * Integer input-- maximum constructor test.
     */
    @Test
    public final void testIntMaxArgumentConstructor() {
        final int i = 2147483647;
        NaturalNumber a = this.constructorTest(i);
        NaturalNumber aExpected = this.constructorRef(i);
        assertEquals(aExpected, a);
    }

    /**
     * String input--normal constructor test.
     */
    @Test
    public final void testString1ArgumentConstructor() {
        String s = "5";
        NaturalNumber a = this.constructorTest(s);
        NaturalNumber aExpected = this.constructorRef(s);
        assertEquals(aExpected, a);
    }

    /**
     * NaturalNumber input--0 constructor test.
     */
    @Test
    public final void testNN0ArgumentConstructor() {
        NaturalNumber n = this.constructorRef(0);
        NaturalNumber a = this.constructorTest(n);
        NaturalNumber aExpected = this.constructorRef(n);
        assertEquals(aExpected, a);
    }

    /**
     * NaturalNumber input--normal constructor test.
     */
    @Test
    public final void testNNNormalArgumentConstructor() {
        final int i = 5;
        NaturalNumber n = this.constructorRef(i);
        NaturalNumber a = this.constructorTest(n);
        NaturalNumber aExpected = this.constructorRef(n);
        assertEquals(aExpected, a);
    }

    /**
     * NaturalNumber input--strange number constructor test.
     */
    @Test
    public final void testNNStrangeArgumentConstructor() {
        final int i = 1234567890;
        NaturalNumber n = this.constructorRef(i);
        NaturalNumber a = this.constructorTest(n);
        NaturalNumber aExpected = this.constructorRef(n);
        assertEquals(aExpected, a);
    }

    /**
     * A boundary test case to check multiplyBy10.
     */
    @Test
    public final void testMultiplyBy10From0To0() {
        NaturalNumber a = this.constructorTest();
        NaturalNumber aExpected = this.constructorRef();
        a.multiplyBy10(0);
        assertEquals(aExpected, a);
    }

    /**
     * A routine test case to check multiplyBy10.
     */
    @Test
    public final void testMultiplyBy10Add0() {
        final int i = 12345;
        final int iExp = 123450;
        NaturalNumber a = this.constructorTest(i);
        NaturalNumber aExpected = this.constructorRef(iExp);
        a.multiplyBy10(0);
        assertEquals(aExpected, a);
    }

    /**
     * A routine test case to check multiplyBy10.
     */
    @Test
    public final void testMultiplyBy10Add1() {
        final int i = 12345;
        final int iExp = 123451;
        NaturalNumber a = this.constructorTest(i);
        NaturalNumber aExpected = this.constructorRef(iExp);
        a.multiplyBy10(1);
        assertEquals(aExpected, a);
    }

    /**
     * A boundary test case to check multiplyBy10.
     */
    @Test
    public final void testDividedBy10From0To0() {
        NaturalNumber a = this.constructorTest();
        NaturalNumber aExpected = this.constructorRef();
        int k = a.divideBy10();
        assertEquals(aExpected, a);
        assertEquals(k, 0);
    }

    /**
     * A routine test case to check DividedBy10.
     */
    @Test
    public final void testDividedBy10From1To0() {
        NaturalNumber a = this.constructorTest(1);
        NaturalNumber aExpected = this.constructorRef();
        int k = a.divideBy10();
        assertEquals(aExpected, a);
        assertEquals(k, 1);
    }

    /**
     * A routine test case to check DividedBy10.
     */
    @Test
    public final void testDividedBy10With0ends() {
        final int i = 12340;
        final int iExp = 1234;
        NaturalNumber a = this.constructorTest(i);
        NaturalNumber aExpected = this.constructorRef(iExp);
        int k = a.divideBy10();
        assertEquals(aExpected, a);
        assertEquals(k, 0);
    }

    /**
     * A routine test case to check DividedBy10.
     */
    @Test
    public final void testDividedBy10With5ends() {
        final int i = 12345;
        final int iExp = 1234;
        final int five = 5;
        NaturalNumber a = this.constructorTest(i);
        NaturalNumber aExpected = this.constructorRef(iExp);
        int k = a.divideBy10();
        assertEquals(aExpected, a);
        assertEquals(k, five);
    }

    /**
     * A challenge test case to test DividedBy10, exceed int.max.
     */
    @Test
    public final void testDividedBy10With5endsEx() {
        final int five = 5;
        NaturalNumber a = this.constructorTest("12345123451234512345");
        NaturalNumber aExpected = this.constructorRef("1234512345123451234");
        int k = a.divideBy10();
        assertEquals(aExpected, a);
        assertEquals(k, five);
    }

    /**
     * A boundary test case to check IsZero method.
     */
    @Test
    public final void testIsZero() {
        NaturalNumber a = this.constructorTest();
        NaturalNumber aExpected = this.constructorRef();
        assertTrue(a.isZero());
        assertEquals(aExpected, a);
    }

    /**
     * A boundary test case to check IsZero method with Integer_Max.
     */
    @Test
    public final void testIsZeroIntMax() {
        final int max = 2147483647;
        NaturalNumber a = this.constructorTest(max);
        NaturalNumber aExpected = this.constructorRef(max);
        assertTrue(!a.isZero());
        assertEquals(aExpected, a);
    }

    /**
     * A routine test case to check IsZero method.
     */
    @Test
    public final void testIsNotZero() {
        final int i = 12345;
        NaturalNumber a = this.constructorTest(i);
        NaturalNumber aExpected = this.constructorRef(i);
        assertTrue(!a.isZero());
        assertEquals(aExpected, a);
    }

    /**
     * A routine test case to check IsZero method.
     */
    @Test
    public final void testIsZeroWithStringInput() {
        NaturalNumber a = this.constructorTest("12345");
        NaturalNumber aExpected = this.constructorRef("12345");
        assertTrue(!a.isZero());
        assertEquals(aExpected, a);
    }

    /**
     * A challenge test case to check IsZero method.
     */
    @Test
    public final void testIsZeroWithNaturalNumber() {
        NaturalNumber n = this.constructorRef("21474836480");
        NaturalNumber a = this.constructorTest(n);
        NaturalNumber aExpected = this.constructorRef(n);
        assertTrue(!a.isZero());
        assertEquals(aExpected, a);
    }
}
