import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.map.Map;
import components.map.Map.Pair;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Zhiren Xu Zhizhou He
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @paramap args the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @paramap args the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     * Routine test to see if constructor build a map or not.
     */
    @Test

    public void testConsructor1() {
        Map<String, String> map = this.createFromArgsTest();
        Map<String, String> expectedMap = this.createFromArgsRef();
        assertEquals(expectedMap, map);
    }

    /**
     * Routine test case for constructor from client view.
     */
    @Test
    public void testConstructor2() {
        Map<String, String> map = this.createFromArgsTest("1", "2");
        Map<String, String> expectedMap = this.createFromArgsRef("1", "2");
        assertEquals(expectedMap, map);
        assertEquals(expectedMap.size(), map.size());
    }

    /**
     * Boundary test case for add method from client view.
     */
    @Test
    public final void testaddToEmpty() {
        Map<String, String> map = this.createFromArgsTest();
        Map<String, String> expectedMap = this.createFromArgsRef("one", "1");
        map.add("one", "1");
        assertEquals(expectedMap, map);
    }

    /**
     * Routine test case for addTo method from client view, and check array
     * size.
     */
    @Test
    public final void testaddNonEmpty() {
        Map<String, String> map = this.createFromArgsTest("two", "2");
        Map<String, String> expectedMap = this.createFromArgsRef("one", "1",
                "two", "2");
        map.add("one", "1");
        int expectSize = expectedMap.size();
        int actualSize = map.size();
        assertEquals(expectedMap, map);
        assertEquals(expectSize, actualSize);
    }

    /**
     * Boundary test case to remove pair from a map, the map become empty.
     */
    @Test
    public final void testRemoveToEmpty() {
        Map<String, String> map = this.createFromArgsTest("one", "1");
        Map<String, String> expectedMap = this.createFromArgsRef();
        Pair<String, String> p = map.remove("one");
        assertEquals(expectedMap, map);
        assertEquals(p.key(), "one");
        assertEquals(p.value(), "1");
    }

    /**
     * Routine test case to move a pair from the map.
     */
    @Test
    public final void testRemoveToNonEmpty() {
        Map<String, String> map = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        Map<String, String> expectedMap = this.createFromArgsRef("two", "2",
                "three", "3");
        Pair<String, String> p = map.remove("one");
        assertEquals(expectedMap, map);
        assertEquals(p.key(), "one");
        assertEquals(p.value(), "1");
    }

    /**
     * Boundary test case for removeAny, the map should be empty. Then check if
     * map size is 0.
     */
    @Test
    public final void testRemoveAnyToEmpty() {
        Map<String, String> map = this.createFromArgsTest("one", "1");
        Map<String, String> expectedMap = this.createFromArgsRef();
        Pair<String, String> p = map.removeAny();
        int expectSize = expectedMap.size();
        int actualSize = map.size();
        assertTrue(!map.hasKey(p.key()));
        assertEquals(expectedMap, map);
        assertEquals(p.key(), "one");
        assertEquals(p.value(), "1");
        assertEquals(expectSize, actualSize);
    }

    /**
     * Routine test case for removeAny.
     */
    @Test
    public final void testRemoveAnyToNonEmpty() {
        Map<String, String> map = this.createFromArgsTest("one", "1", "two",
                "2");
        Map<String, String> expectedMap = this.createFromArgsRef("one", "1",
                "two", "2");
        Pair<String, String> p = map.removeAny();
        assertTrue(!map.hasKey(p.key()));
        expectedMap.remove(p.key());
        int expectSize = expectedMap.size();
        int actualSize = map.size();
        assertEquals(expectedMap, map);
        assertEquals(expectSize, actualSize);
    }

    /**
     * Boundary test case for value method with map contains only one pair.
     */
    @Test
    public final void testValueOnlyone() {
        Map<String, String> map = this.createFromArgsTest("one", "1");
        Map<String, String> expectedMap = this.createFromArgsRef("one", "1");
        String value = map.value("one");
        assertEquals(expectedMap, map);
        assertEquals("1", value);
    }

    /**
     * Routine test case for value method.
     */
    @Test
    public final void testValueCommonCase() {
        Map<String, String> map = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        Map<String, String> expectedMap = this.createFromArgsRef("one", "1",
                "two", "2", "three", "3");
        String value = map.value("three");
        assertEquals(expectedMap, map);
        assertEquals("3", value);
    }

    /**
     * Boundary case to check hasKey with an empty map.
     */
    @Test
    public final void testHasKeyEmpty() {
        Map<String, String> map = this.createFromArgsTest();
        Map<String, String> expectedMap = this.createFromArgsRef();
        boolean value = map.hasKey("one");
        assertEquals(expectedMap, map);
        assertTrue(!value);
    }

    /**
     * Routine test case for hasKey method.
     */
    @Test
    public final void testHasKey() {
        Map<String, String> map = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        Map<String, String> expectedMap = this.createFromArgsRef("one", "1",
                "two", "2", "three", "3");
        boolean value = map.hasKey("one");
        assertEquals(expectedMap, map);
        assertTrue(value);
    }

    /**
     * Challenge case to check a key that isn't in the map.
     */
    @Test
    public final void testNothasKey() {
        Map<String, String> map = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        Map<String, String> expectedMap = this.createFromArgsRef("one", "1",
                "two", "2", "three", "3");
        boolean value = map.hasKey("four");
        assertEquals(expectedMap, map);
        assertTrue(!value);
    }

    /**
     * Challenge case to check an empty condition.
     */
    @Test
    public final void testSizeEmpty() {
        Map<String, String> map = this.createFromArgsTest();
        Map<String, String> expectedMap = this.createFromArgsRef();
        int l = map.size();
        assertEquals(expectedMap, map);
        assertEquals(0, l);
    }

    /**
     * Routine case to check a an non-empty condition.
     */
    @Test
    public final void testsizeNonEmpty() {
        Map<String, String> map = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        Map<String, String> expectedMap = this.createFromArgsRef("one", "1",
                "two", "2", "three", "3");
        int l = map.size();
        assertEquals(expectedMap, map);
        assertEquals(3, l);
    }

    /**
     * Routine case to check replacing value.
     */
    @Test
    public final void testReplaceValue() {
        Map<String, String> map = this.createFromArgsTest("one", "1", "two",
                "2", "three", "3");
        Map<String, String> expectedMap = this.createFromArgsRef("one", "uno",
                "two", "2", "three", "3");
        String value = map.replaceValue("one", "uno");
        assertEquals(expectedMap, map);
        assertEquals("1", value);
    }
}
